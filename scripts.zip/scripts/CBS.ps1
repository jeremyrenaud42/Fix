﻿get-content c:\Windows\logs\cbs\cbs.log | Select-String -Pattern 'SR' -CaseSensitive | out-file $PSScriptRoot\sfcresult.txt
pause

<#

"corrup"
"repair"
"Repairing corrupted file"
"Cannot repair member file"
"Repaired file"
"[SR]"#>